
package tugas;

public class Mahasiswa {
     public static void main(String[] args) {
      String nama = "IRMA NOVI NILAWATI";
      String kelas = "4C";
      String nim = "18090084";
        System.out.println("Nama : "+nama);
        System.out.println("Kelas : "+kelas);
        System.out.println("Nim : "+nim);
        
    }
}
